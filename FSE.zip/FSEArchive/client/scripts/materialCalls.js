mdc.textfield.MDCTextfield.attachTo(document.querySelector('.mdc-textfield'));
mdc.snackbar.MDCSnackbar.attachTo(document.querySelector('.mdc-snackbar'));
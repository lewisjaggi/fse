
module.exports = function(publicEndpoint, privateEndpoint) {
	require('dotenv').config({ path: "keys.env" });
	const express = require('express');
	const router = express.Router();
	const request = require('request');
	const pubEndpoint = publicEndpoint;
	const priEndpoint = privateEndpoint;
	const MAPS_KEY = process.env.GMAP;
	/**
	 * Client routes
	 */
	
	//Route to get the homepage of the site
	router.get('/', (req, res) => {
	    res.render('home', {API_KEY:MAPS_KEY, ENDPOINT_URL:pubEndpoint});
	});
	
	//Route to get the details page of a specific event
	router.get('/events/:id/detail', (req, res) => {
	    const options = {
	        method: 'GET',
	        url: `${priEndpoint}/events/${req.params.id}/details`,
	    }
	
	    request(options, (error, response, body) => {
	        if (!error && response.statusCode == 200) {
	            const event = JSON.parse(body);
	            res.render('eventDetail', { event: event, API_KEY:MAPS_KEY, ENDPOINT_URL:pubEndpoint });
	        } else {
	            res.sendStatus(404);
	        }
	    });
	});
	return router;
}


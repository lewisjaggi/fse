const argv = require('minimist')(process.argv.slice(2));

const app = require('./app')(argv['serverPublic'], argv['serverPublic']);


const server = app.listen(8080, '0.0.0.0', () => {
  console.log(`Express client running → ADDRESS http://${server.address().address}:${server.address().port}`);
});
